# Méthodologie — positions Q111 à Q200

Les positions Q111 à Q200 ont été complétées comme **estimations prudentes** à partir des lignes politiques publiques, des programmes récents, des familles politiques et des positions déjà renseignées dans le fichier Q1–Q110.

## Codage

- `A` : candidat estimé aligné avec l’option A du dilemme.
- `B` : candidat estimé aligné avec l’option B du dilemme.
- `N` : position trop incertaine, neutre ou non renseignée.

## Limite

Ces estimations sont exploitables pour un prototype produit et des tests UX, mais elles doivent être vérifiées candidat par candidat avant publication officielle ou communication publique.
