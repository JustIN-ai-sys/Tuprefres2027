# Tu préfères 2027 — Replit final

Application web Node.js / Express pour tester des dilemmes politiques “Tu préfères ?”.

## Contenu

- 200 questions intégrées dans `data/questions.json`
- 23 candidats dans `data/candidates.json`
- Positions A/B/N dans `data/positions.json`
- Positions détaillées d'origine dans `data/positions_detaillees.json`
- Votes anonymes dans `data/votes.json`
- Résultats finaux anonymes dans `data/results.json`
- Page admin : `/admin`
- Page méthodologie : `/methodologie`

## Lancement sur Replit

1. Importe le ZIP dans Replit.
2. Lance :

```bash
npm install
npm start
```

La commande Replit est déjà configurée dans `.replit`.

## Mot de passe admin

Par défaut :

```txt
admin2027
```

À changer dans Replit Secrets :

```txt
ADMIN_PASSWORD=ton_mot_de_passe
```

## Scoring

- Réponse A : +1 aux candidats positionnés A
- Réponse B : +1 aux candidats positionnés B
- Réponse Neutre : 0 point
- Candidat neutre / inconnu : 0 point

## Données utilisateur

L'application ne demande pas de compte, nom, email ou information personnelle. Les votes sont enregistrés avec un identifiant de session aléatoire et servent aux statistiques globales et à l'amélioration du test.

## Note importante

Les positions candidates Q111 à Q200 sont, dans le fichier combiné actuel, majoritairement non renseignées. Elles sont donc réglées sur `N` par défaut tant qu'elles ne sont pas complétées. Pour un scoring complet sur les 200 questions, il faudra compléter `data/positions.json`.

Généré le 2026-06-01 12:50.


## Positions Q111 à Q200 complétées

Les positions candidats pour Q111 à Q200 ont été ajoutées dans `data/positions.json` et `data/positions_detaillees.json`. Elles sont estimées à partir des lignes politiques publiques et doivent être vérifiées avant publication officielle.
