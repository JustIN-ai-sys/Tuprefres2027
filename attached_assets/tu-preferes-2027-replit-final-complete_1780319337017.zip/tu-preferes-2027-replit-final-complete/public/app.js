let sessionId = null;
let questions = [];
let currentIndex = 0;
let answers = {};

const screens = {
  start: document.getElementById("start"),
  quiz: document.getElementById("quiz"),
  results: document.getElementById("results")
};

const progressText = document.getElementById("progressText");
const themeText = document.getElementById("themeText");
const bar = document.getElementById("bar");
const questionTitle = document.getElementById("questionTitle");
const textA = document.getElementById("textA");
const textB = document.getElementById("textB");
const top3 = document.getElementById("top3");
const ranking = document.getElementById("ranking");

function show(name) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[name].classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}

async function start() {
  try {
    const session = await api("/api/session", { method: "POST", body: "{}" });
    sessionId = session.sessionId;

    const data = await api("/api/questions?count=40");
    questions = data.questions;
    currentIndex = 0;
    answers = {};

    show("quiz");
    render();
  } catch (error) {
    alert("Impossible de lancer le test. Vérifie que le serveur Replit est bien démarré.");
    console.error(error);
  }
}

function render() {
  const q = questions[currentIndex];
  progressText.textContent = `Question ${currentIndex + 1} / ${questions.length}`;
  themeText.textContent = q.bloc || q.theme || "Thème";
  bar.style.width = `${(currentIndex / questions.length) * 100}%`;
  questionTitle.textContent = q.question;
  textA.textContent = q.optionA;
  textB.textContent = q.optionB;
}

async function choose(choice) {
  const q = questions[currentIndex];
  answers[q.id] = choice;

  try {
    await api("/api/vote", {
      method: "POST",
      body: JSON.stringify({ sessionId, questionId: q.id, choice })
    });
  } catch (err) {
    console.warn("Vote non sauvegardé, continuation locale", err);
  }

  currentIndex++;
  if (currentIndex >= questions.length) return finish();
  render();
}

async function finish() {
  bar.style.width = "100%";
  try {
    const data = await api("/api/finish", {
      method: "POST",
      body: JSON.stringify({ sessionId, answers })
    });
    renderResults(data.ranking);
    show("results");
  } catch (error) {
    alert("Impossible de calculer le résultat. Vérifie que le serveur Replit est bien démarré.");
    console.error(error);
  }
}

function renderResults(list) {
  top3.innerHTML = list.slice(0, 3).map((c, i) => `
    <div class="card top-card">
      <div class="rank">#${i + 1}</div>
      <h3>${c.name}</h3>
      <p>${c.party || ""}</p>
      <p><strong>${c.score} points</strong> · ${c.percentage}%</p>
    </div>
  `).join("");

  ranking.innerHTML = list.map((c, i) => `
    <div class="row">
      <div class="rank">#${i + 1}</div>
      <div>
        <div class="name">${c.name}</div>
        <div class="party">${c.party || ""}</div>
      </div>
      <div class="score">${c.score} pts · ${c.percentage}%</div>
    </div>
  `).join("");
}

document.getElementById("startBtn").addEventListener("click", start);
document.getElementById("restartBtn").addEventListener("click", () => show("start"));
document.getElementById("btnA").addEventListener("click", () => choose("A"));
document.getElementById("btnB").addEventListener("click", () => choose("B"));
document.getElementById("btnN").addEventListener("click", () => choose("N"));