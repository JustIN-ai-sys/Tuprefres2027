const express = require("express");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin2027";

const DATA_DIR = path.join(__dirname, "data");
const paths = {
  questions: path.join(DATA_DIR, "questions.json"),
  candidates: path.join(DATA_DIR, "candidates.json"),
  positions: path.join(DATA_DIR, "positions.json"),
  detailedPositions: path.join(DATA_DIR, "positions_detaillees.json"),
  votes: path.join(DATA_DIR, "votes.json"),
  results: path.join(DATA_DIR, "results.json")
};

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function readJson(file, fallback) {
  try {
    if (!fs.existsSync(file)) {
      fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
      return fallback;
    }
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (error) {
    console.error("Erreur JSON:", file, error);
    return fallback;
  }
}

function writeJson(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

function getQuestions() { return readJson(paths.questions, []); }
function getCandidates() { return readJson(paths.candidates, []); }
function getPositions() { return readJson(paths.positions, {}); }

function randomId() {
  return crypto.randomUUID ? crypto.randomUUID() : crypto.randomBytes(16).toString("hex");
}

function shuffle(array) {
  const arr = [...array];
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr;
}

function selectBalancedQuestions(allQuestions, count = 40) {
  if (!count || count >= allQuestions.length) return shuffle(allQuestions);

  const groups = new Map();
  allQuestions.forEach(q => {
    const key = q.bloc || q.theme || "Autres";
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(q);
  });

  const groupEntries = [...groups.entries()].map(([key, qs]) => [key, shuffle(qs)]);
  const selected = [];

  // Round-robin to keep themes balanced.
  while (selected.length < count && groupEntries.some(([, qs]) => qs.length)) {
    for (const [, qs] of groupEntries) {
      if (selected.length >= count) break;
      if (qs.length) selected.push(qs.shift());
    }
  }

  return shuffle(selected);
}

function computeResults(answers) {
  const candidates = getCandidates();
  const positions = getPositions();
  const scores = Object.fromEntries(candidates.map(c => [c.id, 0]));
  const answered = Object.entries(answers).filter(([, choice]) => ["A", "B", "N"].includes(choice));

  answered.forEach(([questionId, choice]) => {
    if (choice === "N") return;
    candidates.forEach(candidate => {
      const pos = positions[candidate.id]?.[questionId] || "N";
      if (pos !== "N" && pos === choice) scores[candidate.id] += 1;
    });
  });

  const nonNeutralCount = answered.filter(([, choice]) => choice !== "N").length;

  return candidates
    .map(candidate => ({
      ...candidate,
      score: scores[candidate.id] || 0,
      percentage: nonNeutralCount ? Math.round(((scores[candidate.id] || 0) / nonNeutralCount) * 100) : 0
    }))
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
}

function requireAdmin(req, res, next) {
  const password = req.headers["x-admin-password"] || req.query.password;
  if (password !== ADMIN_PASSWORD) return res.status(401).json({ error: "Unauthorized" });
  next();
}

app.get("/api/health", (req, res) => res.json({ ok: true, app: "Tu préfères 2027" }));

app.get("/api/questions", (req, res) => {
  const count = Number(req.query.count || 40);
  const mode = req.query.mode || "standard";
  const all = getQuestions();
  const selected = mode === "complete" ? shuffle(all) : selectBalancedQuestions(all, count);
  res.json({ questions: selected, totalAvailable: all.length });
});

app.get("/api/candidates", (req, res) => res.json({ candidates: getCandidates() }));

app.post("/api/session", (req, res) => {
  res.json({ sessionId: randomId() });
});

app.post("/api/vote", (req, res) => {
  const { sessionId, questionId, choice } = req.body || {};
  if (!sessionId || !questionId || !["A", "B", "N"].includes(choice)) {
    return res.status(400).json({ error: "Invalid vote payload" });
  }

  const votes = readJson(paths.votes, []);
  votes.push({
    id: randomId(),
    sessionId,
    questionId,
    choice,
    createdAt: new Date().toISOString()
  });
  writeJson(paths.votes, votes);
  res.json({ ok: true });
});

app.post("/api/finish", (req, res) => {
  const { sessionId, answers } = req.body || {};
  if (!sessionId || !answers || typeof answers !== "object") {
    return res.status(400).json({ error: "Invalid finish payload" });
  }

  const ranking = computeResults(answers);
  const results = readJson(paths.results, []);
  results.push({
    id: randomId(),
    sessionId,
    answers,
    ranking: ranking.map(c => ({ id: c.id, name: c.name, score: c.score, percentage: c.percentage })),
    createdAt: new Date().toISOString()
  });
  writeJson(paths.results, results);
  res.json({ ranking });
});

app.get("/api/admin/stats", requireAdmin, (req, res) => {
  const votes = readJson(paths.votes, []);
  const results = readJson(paths.results, []);
  const questions = getQuestions();

  const byQuestion = {};
  questions.forEach(q => {
    byQuestion[q.id] = {
      questionId: q.id,
      theme: q.theme,
      bloc: q.bloc,
      question: q.question,
      optionA: q.optionA,
      optionB: q.optionB,
      A: 0,
      B: 0,
      N: 0,
      total: 0
    };
  });

  votes.forEach(v => {
    if (!byQuestion[v.questionId]) return;
    byQuestion[v.questionId][v.choice] += 1;
    byQuestion[v.questionId].total += 1;
  });

  const winners = {};
  results.forEach(r => {
    const winner = r.ranking?.[0]?.name;
    if (winner) winners[winner] = (winners[winner] || 0) + 1;
  });

  res.json({
    totalVotes: votes.length,
    totalFinishedTests: results.length,
    winners,
    byQuestion: Object.values(byQuestion).sort((a, b) => Number(a.questionId.slice(1)) - Number(b.questionId.slice(1)))
  });
});

app.get("/admin", (req, res) => res.sendFile(path.join(__dirname, "public", "admin.html")));
app.get("/methodologie", (req, res) => res.sendFile(path.join(__dirname, "public", "methodologie.html")));

app.listen(PORT, () => console.log(`Tu préfères 2027 lancé sur le port ${PORT}`));