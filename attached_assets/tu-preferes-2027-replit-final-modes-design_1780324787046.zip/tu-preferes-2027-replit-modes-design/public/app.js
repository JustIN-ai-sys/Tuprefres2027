let sessionId = null;
let allQuestions = [];
let questions = [];
let currentIndex = 0;
let answers = {};
let selectedCount = 40;

const screens = {
  start: document.getElementById("start"),
  quiz: document.getElementById("quiz"),
  results: document.getElementById("results")
};

const progressText = document.getElementById("progressText");
const themeText = document.getElementById("themeText");
const bar = document.getElementById("bar");
const questionTitle = document.getElementById("questionTitle");
const textA = document.getElementById("textA");
const textB = document.getElementById("textB");
const top3 = document.getElementById("top3");
const ranking = document.getElementById("ranking");

function show(name) {
  Object.values(screens).forEach(s => s.classList.remove("active"));
  screens[name].classList.add("active");
}

async function api(url, options = {}) {
  const res = await fetch(url, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}

function shuffle(array) {
  const copy = [...array];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function selectBalancedQuestions(all, count) {
  if (all.length <= count) return shuffle(all);

  const byTheme = {};
  all.forEach(q => {
    const theme = q.theme || "Autre";
    if (!byTheme[theme]) byTheme[theme] = [];
    byTheme[theme].push(q);
  });

  Object.keys(byTheme).forEach(theme => {
    byTheme[theme] = shuffle(byTheme[theme]);
  });

  const themes = shuffle(Object.keys(byTheme));
  const selected = [];
  let cursor = 0;

  while (selected.length < count) {
    const theme = themes[cursor % themes.length];
    const bucket = byTheme[theme];
    if (bucket && bucket.length > 0) selected.push(bucket.shift());
    cursor += 1;
    if (cursor > count * themes.length * 3) break;
  }

  if (selected.length < count) {
    const already = new Set(selected.map(q => q.id));
    const remaining = shuffle(all.filter(q => !already.has(q.id)));
    selected.push(...remaining.slice(0, count - selected.length));
  }

  return selected.slice(0, count);
}

async function start(count) {
  selectedCount = count;
  const session = await api("/api/session", { method: "POST", body: "{}" });
  sessionId = session.sessionId;

  const data = await api("/api/questions");
  allQuestions = data.questions || [];
  questions = selectBalancedQuestions(allQuestions, selectedCount);

  currentIndex = 0;
  answers = {};
  show("quiz");
  render();
}

function render() {
  const q = questions[currentIndex];
  progressText.textContent = `Question ${currentIndex + 1} / ${questions.length}`;
  themeText.textContent = q.theme || "";
  bar.style.width = `${(currentIndex / questions.length) * 100}%`;
  questionTitle.textContent = q.question || "Choisis une option";
  textA.textContent = q.optionA;
  textB.textContent = q.optionB;
}

async function choose(choice) {
  const q = questions[currentIndex];
  answers[q.id] = choice;

  try {
    await api("/api/vote", {
      method: "POST",
      body: JSON.stringify({ sessionId, questionId: q.id, choice, modeQuestionCount: selectedCount })
    });
  } catch (err) {
    console.warn("Vote non sauvegardé, continuation locale", err);
  }

  currentIndex++;
  if (currentIndex >= questions.length) return finish();
  render();
}

async function finish() {
  bar.style.width = "100%";
  const data = await api("/api/finish", {
    method: "POST",
    body: JSON.stringify({ sessionId, answers, modeQuestionCount: selectedCount })
  });
  renderResults(data.ranking);
  show("results");
}

function renderResults(list) {
  top3.innerHTML = list.slice(0, 3).map((c, i) => `
    <div class="card">
      <div class="rank">#${i + 1}</div>
      <h3>${c.name}</h3>
      <p>${c.party || ""}</p>
      <p><strong>${c.score} points</strong></p>
    </div>
  `).join("");

  ranking.innerHTML = list.map((c, i) => `
    <div class="row">
      <div class="rank">#${i + 1}</div>
      <div>
        <div class="name">${c.name}</div>
        <div class="party">${c.party || ""}</div>
      </div>
      <div class="score">${c.score}</div>
    </div>
  `).join("");
}

document.querySelectorAll(".mode-card").forEach(button => {
  button.addEventListener("click", () => start(Number(button.dataset.count || 40)));
});

document.getElementById("restartBtn").addEventListener("click", () => show("start"));
document.getElementById("btnA").addEventListener("click", () => choose("A"));
document.getElementById("btnB").addEventListener("click", () => choose("B"));
document.getElementById("btnN").addEventListener("click", () => choose("N"));
